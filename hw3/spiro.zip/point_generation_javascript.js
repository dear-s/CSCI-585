<html>
<head>
<script type="text/javascript">

var R=0.005, r=0.001, a=0.004;
var x0=R+r-a, y0=0;
var xx0=34.020839;
var yy1=-118.285557;

var cos=Math.cos;
var sin=Math.sin;
var pi=Math.PI;
var nRev=10;

for(var t=0.0;t<(pi*nRev);t+=0.001)
{
	var x=(R+r)*cos((r/R)*t)-a*cos((1+r/R)*t);
	var y=(R+r)*sin((r/R)*t)-a*sin((1+r/R)*t);
	x=x+xx0;
	y=y+yy1;
	
	document.write(y+","+x+"<br>");
}

</script>
</head>
</html>

